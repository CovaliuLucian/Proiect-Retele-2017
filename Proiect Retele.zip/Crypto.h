//
// Created by luci on 13.01.2018.
//

#ifndef PROIECT_RETELE_CRYPTO_H
#define PROIECT_RETELE_CRYPTO_H


#include <string>

class Crypto {
public:
    static std::string sha256(const std::string &str);
};


#endif //PROIECT_RETELE_CRYPTO_H
